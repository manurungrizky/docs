package KomiCommonSNAPUtils.javaservices;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import org.json.JSONObject;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wm.app.b2b.server.jaxrpc.MessageContext;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.cert.CertificateFactory;
import java.util.Base64;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.security.spec.X509EncodedKeySpec;
import java.security.interfaces.RSAPrivateKey;
import com.wm.data.IData;
import com.wm.data.IDataCursor;
import com.wm.data.IDataUtil;
import com.wm.passman.PasswordManagerException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.digest.DigestUtils;
import com.wm.app.b2b.server.globalvariables.GlobalVariablesException;
import com.wm.app.b2b.server.globalvariables.GlobalVariablesManager;
import com.wm.util.GlobalVariables;
import com.wm.util.GlobalVariables.GlobalVariableValue;
// --- <<IS-END-IMPORTS>> ---

public final class signatureV2

{
	// ---( internal utility methods )---

	final static signatureV2 _instance = new signatureV2();

	static signatureV2 _newInstance() { return new signatureV2(); }

	static signatureV2 _cast(Object o) { return (signatureV2)o; }

	// ---( server methods )---




	public static final void exceptionHandling (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(exceptionHandling)>> ---
		// @sigtype java 3.5
		// [i] field:0:required payload
		// [o] object:0:required statusCode
		// [o] field:0:required statusMessage
		IDataCursor pipelineCursor = pipeline.getCursor();
		String JAVA_SERVICE = "[ExceptionHandling] ";
		String payload = IDataUtil.getString(pipelineCursor, "payload");
		logMessageToServerLog(pipeline, JAVA_SERVICE + "payload = " + payload);
		pipelineCursor.destroy();
				
		IDataCursor pipelineCursorOut = pipeline.getCursor();
		IDataUtil.put( pipelineCursorOut, "statusCode", Integer.parseInt(payload.split("#")[1]));
		IDataUtil.put( pipelineCursorOut, "statusMessage", payload.split("#")[2]);
		pipelineCursorOut.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void hmacSHA512 (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(hmacSHA512)>> ---
		// @sigtype java 3.5
		// [i] field:0:required secretKey
		// [i] field:0:required timestampRequest
		// [i] field:0:required bodyRequest
		// [i] field:0:required resourceUrl
		// [i] field:0:required httpMethod
		// [i] field:0:required accessToken
		// [o] field:0:required encodedData
		// [o] field:0:required message
		// [o] field:0:required payloadHmac
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String JAVA_SERVICE = "[HmacSha512] ";
		String	secretKey = IDataUtil.getString( pipelineCursor, "secretKey" );
		String	bodyRequest = IDataUtil.getString( pipelineCursor, "bodyRequest" );
		String	httpMethod = IDataUtil.getString( pipelineCursor, "httpMethod" );
		String	resourceUrl = IDataUtil.getString( pipelineCursor, "resourceUrl" );
		String	accessToken = IDataUtil.getString( pipelineCursor, "accessToken" );
		String	timestampRequest = IDataUtil.getString( pipelineCursor, "timestampRequest" );
		
		String data = "";
		String bodyHash = "";
		
		ObjectMapper objectMapper = new ObjectMapper();
		
		try {
			JsonNode jsonNode = objectMapper.readValue(bodyRequest, JsonNode.class);
			bodyRequest = jsonNode.toString();
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		
		byte[] sha256Bytes = DigestUtils.sha256(bodyRequest);		
		bodyHash = Hex.encodeHexString(sha256Bytes).toLowerCase();
		data = httpMethod+":"+resourceUrl+":"+accessToken+":"+bodyHash+":"+timestampRequest;		
		
		try {
			SecretKeySpec signingKey = new SecretKeySpec(secretKey.getBytes(), SHA512ALGORITHM);
			Mac mac = Mac.getInstance(SHA512ALGORITHM);
			mac.init(signingKey);
		
			byte[] resultHex = mac.doFinal(data.getBytes());
		
			String encodedData = bytesToHex(resultHex);
			if(encodedData!=null)
		
			IDataUtil.put( pipelineCursor, "encodedData", encodedData );
			IDataUtil.put( pipelineCursor, "message", data );
			IDataUtil.put( pipelineCursor, "payloadHmac", bodyRequest);
			pipelineCursor.destroy();
		
			} catch (InvalidKeyException | NoSuchAlgorithmException e) {
				((Throwable) e).printStackTrace();
			}
		// --- <<IS-END>> ---

                
	}



	public static final void validateOAuthSignature (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(validateOAuthSignature)>> ---
		// @sigtype java 3.5
		// [i] field:0:required signature
		// [i] field:0:required clientId
		// [i] field:0:required timestamp
		// [i] field:0:required grantType
		// [i] field:0:required keyPath
		// [o] field:0:required isVerified
		// [o] field:0:required outMessage
		// [o] field:0:required httpCode
		String isVerified = "false";
		String outMessage = "";
		String JAVA_SERVICE = "[ValidateOAuthSignature] ";
			
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	signature = IDataUtil.getString( pipelineCursor, "signature" );
		String	clientId = IDataUtil.getString( pipelineCursor, "clientId" );
		String	timestamp = IDataUtil.getString( pipelineCursor, "timestamp" );
		String	grantType = IDataUtil.getString( pipelineCursor, "grantType" );
		String	keyPath = IDataUtil.getString( pipelineCursor, "keyPath" );
		
		try{
		
			// Load public key from file
			PublicKey pubKey = loadPublicKey(keyPath);
		
			//validate grant type
			if(grantType==null || grantType.equals("")){
				isVerified = "false";
				outMessage = "400#Bad Request -- 1";
			}else{
				boolean grantTypeFound = false;
					if("client_credentials".equals(grantType)){
						grantTypeFound = true;
						isVerified = "true";
						outMessage = "200#Success";
					} else{					
						isVerified = "false";
						outMessage = "400#Unsupported grant_type";
					}
		
					if(!grantTypeFound){
						isVerified = "true";
						outMessage = "400#Bad Request -- 2";
					}
			}			
		
			if("true".equals(isVerified)){
				//data to be validated					
				String data = clientId+"|"+timestamp;
				byte[] byteData = data.getBytes(StandardCharsets.UTF_8);		
		
				//verify signature
				Signature signn = Signature.getInstance("SHA256withRSA");
				byte[] byteSignature = hexToBytes(signature);
				signn.initVerify(pubKey);
				signn.update(byteData);		
		
				Boolean verified = signn.verify(byteSignature);
		
				if(verified){
					isVerified = "true";
					outMessage = "200#Success";
				}else{
					isVerified = "false";
					outMessage = "401#Unauthorized -- 1";
				}
			}			
		} catch (Exception e) {
			e.printStackTrace();
			logMessageToServerLog(pipeline, JAVA_SERVICE + "error = " + e.getMessage());
			isVerified = "false";
			outMessage = "401#Unauthorized -- 2";
		} finally {
			IDataUtil.put( pipelineCursor, "isVerified", isVerified );
			IDataUtil.put( pipelineCursor, "outMessage", outMessage );
			pipelineCursor.destroy();
		}
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	private static final String SHA512ALGORITHM = "HmacSHA512";
	
	public static String sign(RSAPrivateKey privateKey, String data) {
		
		String signature = null;
	
		try {
			Signature sign = Signature.getInstance("SHA256withRSA");
			sign.initSign(privateKey);
			byte[] byteMessage = data.getBytes();
	
			sign.update(data.getBytes(StandardCharsets.UTF_8));
			byte[] byteSignature = sign.sign();
	
			signature = new String(byteSignature);
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return signature;
	}
	
	public static void logMessageToServerLog(
			IData pipeline, 
		    String message) throws ServiceException{
		logMessageToServerLog(pipeline,"[AdiraAPIUtils]"+message,null,null);
	}
	
	public static void logMessageToServerLog(
		    IData pipeline, 
		    String message, 
		    String function, 
		    String level) 
		    throws ServiceException 
		{ 
		    IDataCursor inputCursor = pipeline.getCursor(); 
		    IDataUtil.put(inputCursor, "message", message); 
		    IDataUtil.put(inputCursor, "function", function); 
		    IDataUtil.put(inputCursor, "level", level); 
		    inputCursor.destroy(); 
	
		    try
		    {
		        Service.doInvoke("pub.flow", "debugLog", pipeline);
		    }
		    catch (Exception e)
		    {
		        throw new ServiceException(e.getMessage());
		    }
		}
	
		private static PublicKey loadPublicKey(String filePath) throws Exception {
	        byte[] keyBytes = Files.readAllBytes(Paths.get(filePath));
	        String publicKeyPEM = new String(keyBytes).replace("-----BEGIN PUBLIC KEY-----", "")
	                                                  .replace("-----END PUBLIC KEY-----", "")
	                                                  .replaceAll("\\s", "");
	        byte[] decodedKey = Base64.getDecoder().decode(publicKeyPEM);
	        X509EncodedKeySpec spec = new X509EncodedKeySpec(decodedKey);
	        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
	        return keyFactory.generatePublic(spec);
	    }
		
		public static String bytesToHex(byte[] bytes) {
		    StringBuilder result = new StringBuilder();
		    for (byte b : bytes) {
		        result.append(String.format("%02x", b));
		    }
		    return result.toString();
		}
		
		public static byte[] hexToBytes(String hexString) {
	        int length = hexString.length();
	        byte[] bytes = new byte[length / 2];
	        for (int i = 0; i < length; i += 2) {
	            bytes[i / 2] = (byte) ((Character.digit(hexString.charAt(i), 16) << 4)
	                    + Character.digit(hexString.charAt(i + 1), 16));
	        }
	        return bytes;
	    }
	// --- <<IS-END-SHARED>> ---
}

