package KomiCommonSNAPUtils.javaservices.validator;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.time.ZonedDateTime;
import java.time.Duration;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
// --- <<IS-END-IMPORTS>> ---

public final class timestampValidator

{
	// ---( internal utility methods )---

	final static timestampValidator _instance = new timestampValidator();

	static timestampValidator _newInstance() { return new timestampValidator(); }

	static timestampValidator _cast(Object o) { return (timestampValidator)o; }

	// ---( server methods )---




	public static final void validateDifference (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(validateDifference)>> ---
		// @sigtype java 3.5
		// [i] field:0:required timestamp
		// [o] field:0:required isValid
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String timestamp = IDataUtil.getString( pipelineCursor, "timestamp" );
		String isValid;
		
		long difference = calculateSecondsDifference(timestamp);
		
		if(difference >= -120 && difference <= 120) {
			isValid = "true";
		} else {
			isValid = "false";
		}
		
		IDataUtil.put( pipelineCursor, "isValid", isValid);
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void validateFormat (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(validateFormat)>> ---
		// @sigtype java 3.5
		// [i] field:0:required timestamp
		// [o] field:0:required isValidTimestampFormat
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String timestamp = IDataUtil.getString( pipelineCursor, "timestamp" );
		
		String isValidTimestampFormat = TimestampValidateFormat(timestamp);		
		
		IDataUtil.put( pipelineCursor, "isValidTimestampFormat", isValidTimestampFormat);
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	// Method to validate timestamp
	public static long calculateSecondsDifference(String timestamp) {
		try {
	        // Parse the input timestamp
	        ZonedDateTime inputTime = ZonedDateTime.parse(timestamp, DateTimeFormatter.ISO_OFFSET_DATE_TIME);
	
	        // Get the current time
	        ZonedDateTime currentTime = ZonedDateTime.now(ZoneId.systemDefault());
	
	        // Calculate the time difference
	        Duration duration = Duration.between(inputTime, currentTime);
	
	        // Return the difference in seconds
	        return duration.getSeconds();
	    } catch (Exception e) {
	        // Handle parsing exception
	        System.err.println("Invalid timestamp format: " + e.getMessage());
	        return 0;
	    }
	}
	
	public static String TimestampValidateFormat(String timestamp) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssXXX");
		
		try {
			ZonedDateTime.parse(timestamp, formatter);
			
			ZonedDateTime dateTime = ZonedDateTime.parse(timestamp, formatter);
			
			if (dateTime.getOffset().getId().equals("+07:00")) {
				return "true";
			} else {
				return "false";
			}
			
		} catch(DateTimeParseException e) {
			return "false";
		}
		
	}
	// --- <<IS-END-SHARED>> ---
}

