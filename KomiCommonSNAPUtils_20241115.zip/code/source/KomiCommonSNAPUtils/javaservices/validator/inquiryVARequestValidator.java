package KomiCommonSNAPUtils.javaservices.validator;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
// --- <<IS-END-IMPORTS>> ---

public final class inquiryVARequestValidator

{
	// ---( internal utility methods )---

	final static inquiryVARequestValidator _instance = new inquiryVARequestValidator();

	static inquiryVARequestValidator _newInstance() { return new inquiryVARequestValidator(); }

	static inquiryVARequestValidator _cast(Object o) { return (inquiryVARequestValidator)o; }

	// ---( server methods )---




	public static final void validate (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(validate)>> ---
		// @sigtype java 3.5
		// [i] field:0:required partnerServiceId
		// [i] field:0:required customerNo
		// [i] field:0:required virtualAccountNo
		// [i] field:0:required value
		// [i] field:0:required currency
		// [i] field:0:required inquiryRequestId
		// [o] field:0:required validateResult
		// [o] field:0:required validateMessage
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	partnerServiceId = IDataUtil.getString( pipelineCursor, "partnerServiceId" );
			String	customerNo = IDataUtil.getString( pipelineCursor, "customerNo" );
			String	virtualAccountNo = IDataUtil.getString( pipelineCursor, "virtualAccountNo" );
			// String	value = IDataUtil.getString( pipelineCursor, "value" );
			// String	currency = IDataUtil.getString( pipelineCursor, "currency" );
			String	inquiryRequestId = IDataUtil.getString( pipelineCursor, "inquiryRequestId" );
		pipelineCursor.destroy();
		
		boolean validate = true;
		String validateResult = "true";
		String validateMessage = "passed";
		
		String patternDecimal = "^\\d+\\.\\d{2}?$";
		String patternNumberOnly = "^\\d+$";
		
		//validasi untuk input partnerServiceId
		if(validate){
			if(partnerServiceId == null){
				validate = false;
				validateResult = "false";
				validateMessage = "Invalid Mandatory Field {partnerServiceId}";
			}else{
				if(partnerServiceId.length() > 8){
					validate = false;
					validateResult = "false";
					validateMessage = "Invalid Field Format {partnerServiceId}";
				}
			}
		}
		
		//validasi untuk input customerNo
		if(validate){
			if(customerNo == null){
				validate = false;
				validateResult = "false";
				validateMessage = "Invalid Mandatory Field {customerNo}";
			}else{
				if(customerNo.length() > 20){
					validate = false;
					validateResult = "false";
					validateMessage = "Invalid Field Format {customerNo}";
				}else{
					if(!customerNo.matches(patternNumberOnly)){
						validate = false;
						validateResult = "false";
						validateMessage = "Invalid Field Format {customerNo}";
					}
				}
			}
		}		
		
		//validasi untuk input virtualAccountNo
		if(validate){
			if(virtualAccountNo == null){
				validate = false;
				validateResult = "false";
				validateMessage = "Invalid Mandatory Field {virtualAccountNo}";
			}else{
				if(virtualAccountNo.length() > 28){
					validate = false;
					validateResult = "false";
					validateMessage = "Invalid Field Format {virtualAccountNo}";
				}
			}
		}
		
		//validasi untuk input value
		//		if(validate){
		//			if(value == null){
		//				validate = false;
		//				validateResult = "false";
		//				validateMessage = "Invalid Mandatory Field {value}";
		//			} else {
		//				if(!value.matches(patternDecimal)){
		//					validate = false;
		//					validateResult = "false";
		//					validateMessage = "Invalid Field Format {value}";
		//				}	
		//			}			
		//		}
		
		//validasi untuk input currency
		//		if(validate){
		//			if(currency == null){
		//				validate = false;
		//				validateResult = "false";
		//				validateMessage = "Invalid Mandatory Field {currency}";
		//			}else{
		//				if(currency.length() > 3){
		//					validate = false;
		//					validateResult = "false";
		//					validateMessage = "Invalid Field Format {currency}";
		//				}
		//			}
		//		}
		
		//validasi untuk input inquiryRequestId
		if(validate){
			if(inquiryRequestId == null){
				validate = false;
				validateResult = "false";
				validateMessage = "Invalid Mandatory Field {inquiryRequestId}";
			}else{
				if(inquiryRequestId.length() > 128){
					validate = false;
					validateResult = "false";
					validateMessage = "Invalid Field Format {inquiryRequestId}";
				}
			}
		}				
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "validateResult", validateResult );
		IDataUtil.put( pipelineCursor_1, "validateMessage", validateMessage );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}
}

