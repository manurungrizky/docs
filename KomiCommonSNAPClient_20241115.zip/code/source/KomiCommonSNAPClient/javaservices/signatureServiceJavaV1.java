package KomiCommonSNAPClient.javaservices;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import org.json.JSONObject;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wm.app.b2b.server.jaxrpc.MessageContext;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.cert.CertificateFactory;
import java.util.Base64;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.security.spec.X509EncodedKeySpec;
import java.security.interfaces.RSAPrivateKey;
import com.wm.data.IData;
import com.wm.data.IDataCursor;
import com.wm.data.IDataUtil;
import com.wm.passman.PasswordManagerException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.codec.digest.DigestUtils;
import com.wm.app.b2b.server.globalvariables.GlobalVariablesException;
import com.wm.app.b2b.server.globalvariables.GlobalVariablesManager;
import com.wm.util.GlobalVariables;
import com.wm.util.GlobalVariables.GlobalVariableValue;
// --- <<IS-END-IMPORTS>> ---

public final class signatureServiceJavaV1

{
	// ---( internal utility methods )---

	final static signatureServiceJavaV1 _instance = new signatureServiceJavaV1();

	static signatureServiceJavaV1 _newInstance() { return new signatureServiceJavaV1(); }

	static signatureServiceJavaV1 _cast(Object o) { return (signatureServiceJavaV1)o; }

	// ---( server methods )---




	public static final void hmacSHA512 (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(hmacSHA512)>> ---
		// @sigtype java 3.5
		// [i] field:0:required secretKey
		// [i] field:0:required timestampRequest
		// [i] field:0:required bodyRequest
		// [i] field:0:required resourceUrl
		// [i] field:0:required httpMethod
		// [i] field:0:required accessToken
		// [o] field:0:required encodedData
		// [o] field:0:required message
		// [o] field:0:required payloadHmac
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String JAVA_SERVICE = "[HmacSha512] ";
		String	secretKey = IDataUtil.getString( pipelineCursor, "secretKey" );
		String	bodyRequest = IDataUtil.getString( pipelineCursor, "bodyRequest" );
		String	httpMethod = IDataUtil.getString( pipelineCursor, "httpMethod" );
		String	resourceUrl = IDataUtil.getString( pipelineCursor, "resourceUrl" );
		String	accessToken = IDataUtil.getString( pipelineCursor, "accessToken" );
		String	timestampRequest = IDataUtil.getString( pipelineCursor, "timestampRequest" );
		
		String data = "";
		String bodyHash = "";
		
		ObjectMapper objectMapper = new ObjectMapper();
		
		try {
		JsonNode jsonNode = objectMapper.readValue(bodyRequest, JsonNode.class);
		bodyRequest = jsonNode.toString();
		
		} catch (Exception e) {
		e.printStackTrace();
		} 
		
		byte[] sha256Bytes = DigestUtils.sha256(bodyRequest);		
		bodyHash = Hex.encodeHexString(sha256Bytes).toLowerCase();
		data = httpMethod+":"+resourceUrl+":"+accessToken+":"+bodyHash+":"+timestampRequest;		
		
		try {
		SecretKeySpec signingKey = new SecretKeySpec(secretKey.getBytes(), SHA512ALGORITHM);
		Mac mac = Mac.getInstance(SHA512ALGORITHM);
		mac.init(signingKey);
		
		byte[] resultHex = mac.doFinal(data.getBytes());
		
		String encodedData = Base64.getEncoder().encodeToString(resultHex);
		if(encodedData!=null)
		
		IDataUtil.put( pipelineCursor, "encodedData", encodedData );
		IDataUtil.put( pipelineCursor, "message", data );
		IDataUtil.put( pipelineCursor, "payloadHmac", bodyRequest);
		pipelineCursor.destroy();
		
		} catch (InvalidKeyException | NoSuchAlgorithmException e) {
		((Throwable) e).printStackTrace();
		}
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	private static final String SHA512ALGORITHM = "HmacSHA512";
	
	public static String sign(RSAPrivateKey privateKey, String data) {
		
		String signature = null;
	
		try {
			Signature sign = Signature.getInstance("SHA256withRSA");
			sign.initSign(privateKey);
			byte[] byteMessage = data.getBytes();
	
			sign.update(byteMessage, 0, byteMessage.length);
			byte[] byteSignature = sign.sign();
	
				signature = new String(Base64.getEncoder().encode(byteSignature));
		
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return signature;
	}
	
	
		
		public static String bytesToHex(byte[] bytes) {
		    StringBuilder result = new StringBuilder();
		    for (byte b : bytes) {
		        result.append(String.format("%02x", b));
		    }
		    return result.toString();
		}
		
		public static byte[] hexToBytes(String hexString) {
	        int length = hexString.length();
	        byte[] bytes = new byte[length / 2];
	        for (int i = 0; i < length; i += 2) {
	            bytes[i / 2] = (byte) ((Character.digit(hexString.charAt(i), 16) << 4)
	                    + Character.digit(hexString.charAt(i + 1), 16));
	        }
	        return bytes;
	    }
	// --- <<IS-END-SHARED>> ---
}

