package KomiCommonSNAPClient.javaservices;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.security.Signature;
import java.security.interfaces.RSAPrivateKey;
import java.util.Base64;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
// --- <<IS-END-IMPORTS>> ---

public final class signatureAuthJavaV2

{
	// ---( internal utility methods )---

	final static signatureAuthJavaV2 _instance = new signatureAuthJavaV2();

	static signatureAuthJavaV2 _newInstance() { return new signatureAuthJavaV2(); }

	static signatureAuthJavaV2 _cast(Object o) { return (signatureAuthJavaV2)o; }

	// ---( server methods )---




	public static final void OAuthSignature (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(OAuthSignature)>> ---
		// @sigtype java 3.5
		// [i] field:0:required clientId
		// [i] field:0:required timestampRequest
		// [o] field:0:required signature
		// [o] field:0:required privateKey
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		
		//populate required data
		String timestampRequest = IDataUtil.getString( pipelineCursor, "timestampRequest" );
		String clientId = IDataUtil.getString( pipelineCursor, "clientId" );
		
		pipelineCursor.destroy();
		
		String keyPath = "/home/user/snap/pkcs8_private_key.pem";	
		
		String data = clientId+"|"+timestampRequest;
		
		String signature = "";
		
		try {
			PrivateKey privateKey = loadPrivateKey(keyPath);		
			// create signature
			signature = sign(privateKey, data);		
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
		IDataCursor pipelineCursorOut = pipeline.getCursor();
		IDataUtil.put( pipelineCursorOut, "signature", signature );
		pipelineCursorOut.destroy();
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	public static String sign(PrivateKey privateKey, String data) {
		
		String signature = null;
	
		try {
			Signature sign = Signature.getInstance("SHA256withRSA");
			sign.initSign(privateKey);
			byte[] byteMessage = data.getBytes();
	
			sign.update(data.getBytes(StandardCharsets.UTF_8));
			byte[] byteSignature = sign.sign();
	
			signature = bytesToHex(byteSignature);
					
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return signature;
	}
	
	public static void logMessageToServerLog(
			IData pipeline, 
		    String message) throws ServiceException{
		logMessageToServerLog(pipeline,"[OAuthSignature] "+message,null,null);
	}
	
	public static void logMessageToServerLog(
		    IData pipeline, 
		    String message, 
		    String function, 
		    String level) 
		    throws ServiceException 
		{ 
		    IDataCursor inputCursor = pipeline.getCursor(); 
		    IDataUtil.put(inputCursor, "message", message); 
		    IDataUtil.put(inputCursor, "function", function); 
		    IDataUtil.put(inputCursor, "level", level); 
		    inputCursor.destroy();
	
		    try
		    {
		        Service.doInvoke("pub.flow", "debugLog", pipeline);
		    }
		    catch (Exception e)
		    {
		        throw new ServiceException(e.getMessage());
		    }
		}
	
	private static PrivateKey loadPrivateKey(String filePath) throws Exception {
	    byte[] keyBytes = Files.readAllBytes(Paths.get(filePath));
	    String privateKeyPEM = new String(keyBytes).replace("-----BEGIN PRIVATE KEY-----", "")
	                                               .replace("-----END PRIVATE KEY-----", "")
	                                               .replaceAll("\\s", "");
	    byte[] decodedKey = Base64.getDecoder().decode(privateKeyPEM);
	    PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(decodedKey);
	    KeyFactory keyFactory = KeyFactory.getInstance("RSA");
	    return keyFactory.generatePrivate(spec);
	}
	
	public static String bytesToHex(byte[] bytes) {
	    StringBuilder result = new StringBuilder();
	    for (byte b : bytes) {
	        result.append(String.format("%02x", b));
	    }
	    return result.toString();
	}
	// --- <<IS-END-SHARED>> ---
}

